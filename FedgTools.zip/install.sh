#!/usr/bin/env bash
# Installs Fedora Toolbox for your user and adds it to the app grid.
set -e
cd "$(dirname "$0")"
sudo dnf install -y python3-gobject gtk4 libadwaita pciutils polkit
dir="$HOME/.local/share/fedora-toolbox"
mkdir -p "$dir" "$HOME/.local/share/applications"
install -m 755 fedora-toolbox.py "$dir/fedora-toolbox.py"
cat > "$HOME/.local/share/applications/fedora-toolbox.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Fedora Toolbox
Comment=System toolbox for Fedora GNOME
Exec=python3 $dir/fedora-toolbox.py
Icon=preferences-system
Terminal=false
Categories=System;Settings;
DESK
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
echo "Done. Open 'Fedora Toolbox' from the Activities overview."
