#!/usr/bin/env python3
"""Fedora Toolbox - a macOS-styled system toolbox for Fedora GNOME (GTK 4 + libadwaita)."""
import glob
import os
import platform
import re
import shlex
import subprocess
import sys
import tempfile
import threading
import xml.etree.ElementTree as ET

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk

HOME = os.path.expanduser("~")
ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
q = shlex.quote
esc = GLib.markup_escape_text

CSS = """
.navigation-sidebar { background: transparent; }
.navigation-sidebar row { border-radius: 9px; margin: 1px 6px; padding: 2px 4px; }
.navigation-sidebar row:selected { background: @accent_bg_color; color: @accent_fg_color; }
.navigation-sidebar row:selected image, .navigation-sidebar row:selected label { color: @accent_fg_color; }
.boxed-list { border-radius: 14px; }
button.suggested-action, button.pill-btn { border-radius: 999px; padding: 5px 16px; }
button.pill-btn { background: alpha(currentColor, 0.08); }
headerbar windowcontrols button { min-width: 13px; min-height: 13px; padding: 0; margin: 0 4px;
  border-radius: 99px; border: none; box-shadow: none; background-image: none; }
headerbar windowcontrols button image { -gtk-icon-size: 8px; opacity: 0; color: rgba(0,0,0,0.65); }
headerbar windowcontrols:hover button image { opacity: 1; }
headerbar windowcontrols button.close { background-color: #ff5f57; }
headerbar windowcontrols button.minimize { background-color: #febc2e; }
headerbar windowcontrols button.maximize { background-color: #28c840; }
"""

# ---------------------------------------------------------------- scripts ---

RPMFUSION = (
    "rpm -q rpmfusion-free-release rpmfusion-nonfree-release >/dev/null 2>&1 || dnf install -y "
    "https://mirrors.rpmfusion.org/free/fedora/rpmfusion-free-release-$(rpm -E %fedora).noarch.rpm "
    "https://mirrors.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-$(rpm -E %fedora).noarch.rpm\n"
)
FLATHUB = "flatpak remote-add --user --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo\n"
CODECS = (
    RPMFUSION
    + "dnf swap -y ffmpeg-free ffmpeg --allowerasing || dnf install -y ffmpeg --allowerasing\n"
    + 'dnf group install -y multimedia sound-and-video --allowerasing --setopt="install_weak_deps=False" '
    + "--exclude=PackageKit-gstreamer-plugin || echo '(optional codec groups skipped)'\n"
)
SCRIPTS = {
    "brave-nightly": (
        "curl -fsSLo /etc/yum.repos.d/brave-browser-nightly.repo "
        "https://brave-browser-rpm-nightly.s3.brave.com/brave-browser-nightly.repo\n"
        "dnf install -y brave-browser-nightly\n"
    ),
    "nvidia-ctk": (
        "curl -fsSL https://nvidia.github.io/libnvidia-container/stable/rpm/nvidia-container-toolkit.repo "
        "-o /etc/yum.repos.d/nvidia-container-toolkit.repo\n"
        "dnf install -y nvidia-container-toolkit\n"
        "mkdir -p /etc/cdi\n"
        "nvidia-ctk cdi generate --output=/etc/cdi/nvidia.yaml || "
        "echo 'Reboot first, then run: sudo nvidia-ctk cdi generate --output=/etc/cdi/nvidia.yaml'\n"
    ),
    "nv-modeset": 'grubby --update-kernel=ALL --args="nvidia-drm.modeset=1 nvidia-drm.fbdev=1"\n',
}

# Entry: (category, name, description, kind, target[, installed-check])
# kinds: flatpak = Flathub (user install), dnf = Fedora repos, fusion = dnf + RPM Fusion, script = SCRIPTS key
APPS = [
    ("Browsers", "Firefox", "Fast, private web browser", "dnf", "firefox"),
    ("Browsers", "Brave Nightly", "Brave's experimental channel, from Brave's own repo", "script", "brave-nightly", "brave-browser-nightly"),
    ("Chat and music", "Discord", "Voice, video and text chat", "flatpak", "com.discordapp.Discord"),
    ("Chat and music", "Vesktop", "Discord client with Vencord and better Wayland screen sharing", "flatpak", "dev.vencord.Vesktop"),
    ("Chat and music", "Spotify", "Music streaming", "flatpak", "com.spotify.Client"),
    ("Chat and music", "Telegram", "Messenger", "flatpak", "org.telegram.desktop"),
    ("Gaming", "Steam", "Game store and launcher (from RPM Fusion)", "fusion", "steam"),
    ("Gaming", "Sober", "Run Roblox on Linux (Flathub)", "flatpak", "org.vinegarhq.Sober"),
    ("Gaming", "Prism Launcher", "Minecraft launcher with separate instances", "flatpak", "org.prismlauncher.PrismLauncher"),
    ("Gaming", "Heroic Games Launcher", "Epic, GOG and Amazon games", "flatpak", "com.heroicgameslauncher.hgl"),
    ("Gaming", "Lutris", "Game manager for Wine and emulators", "dnf", "lutris"),
    ("Gaming", "MangoHud and GameMode", "FPS overlay and performance tweaks for games", "dnf", "mangohud gamemode", "mangohud"),
    ("Gaming", "ProtonUp-Qt", "Install Proton-GE and Wine builds", "flatpak", "net.davidotek.pupgui2"),
    ("Media", "VLC", "Plays nearly anything", "flatpak", "org.videolan.VLC"),
    ("Media", "OBS Studio", "Streaming and screen recording", "flatpak", "com.obsproject.Studio"),
    ("Productivity", "LibreOffice", "Writer, Calc, Impress and friends", "dnf", "libreoffice", "libreoffice-writer"),
    ("Productivity", "Visual Studio Code", "Code editor", "flatpak", "com.visualstudio.code"),
    ("Productivity", "Obsidian", "Markdown notes", "flatpak", "md.obsidian.Obsidian"),
    ("Terminal and dev", "Kitty", "GPU-accelerated terminal", "dnf", "kitty"),
    ("Terminal and dev", "Git", "Version control", "dnf", "git"),
    ("Terminal and dev", "Neovim", "Modal text editor", "dnf", "neovim"),
    ("Terminal and dev", "btop", "Resource monitor for the terminal", "dnf", "btop"),
    ("Terminal and dev", "Fastfetch", "System info in the terminal", "dnf", "fastfetch"),
    ("Terminal and dev", "Distrobox", "Run other distros in containers, handy for CUDA work", "dnf", "distrobox"),
    ("GNOME", "Extension Manager", "Browse and install GNOME extensions", "flatpak", "com.mattjakeman.ExtensionManager"),
    ("GNOME", "GNOME Extensions app", "Turn installed extensions on or off", "dnf", "gnome-extensions-app"),
    ("GNOME", "GNOME Tweaks", "Fonts, themes and more", "dnf", "gnome-tweaks"),
    ("GNOME", "Dash to Dock", "A macOS-style dock", "dnf", "gnome-shell-extension-dash-to-dock"),
    ("GNOME", "AppIndicator", "Tray icons in the top bar", "dnf", "gnome-shell-extension-appindicator"),
    ("GNOME", "User Themes", "Lets you apply GNOME Shell themes", "dnf", "gnome-shell-extension-user-theme"),
    ("Utilities", "Flatseal", "Manage Flatpak permissions", "flatpak", "com.github.tchx84.Flatseal"),
    ("Utilities", "Mission Center", "Task manager with GPU stats", "flatpak", "io.missioncenter.MissionCenter"),
    ("Utilities", "GDM Settings", "Change the login screen background and theme", "flatpak", "io.github.realmazharhussain.GdmSettings"),
]

NV_EXTRAS = [
    ("NVIDIA", "NVIDIA Settings", "Control panel for your GPU", "fusion", "nvidia-settings"),
    ("NVIDIA", "Hardware video decoding", "VA-API on top of NVDEC, for Firefox and video players", "fusion", "libva-nvidia-driver libva-utils", "libva-nvidia-driver"),
    ("NVIDIA", "32-bit libraries", "Needed by Steam, Wine and Proton", "fusion", "xorg-x11-drv-nvidia-libs.i686", "xorg-x11-drv-nvidia-libs.i686"),
    ("NVIDIA", "Power management", "Fixes sleep and resume with the NVIDIA driver", "fusion", "xorg-x11-drv-nvidia-power"),
    ("NVIDIA", "nvtop", "Live GPU usage in the terminal", "dnf", "nvtop"),
    ("NVIDIA", "Vulkan tools", "vulkaninfo and vkcube for testing", "dnf", "vulkan-tools"),
    ("NVIDIA", "Container GPU support", "NVIDIA Container Toolkit for Podman and Docker", "script", "nvidia-ctk", "nvidia-container-toolkit"),
    ("NVIDIA", "Wayland modesetting", "Adds nvidia-drm.modeset=1 to the kernel options", "script", "nv-modeset"),
]

BLOAT = [
    ("Debloat", "Tour", "Welcome tour for new users", "dnf", "gnome-tour"),
    ("Debloat", "Maps", "GNOME Maps", "dnf", "gnome-maps"),
    ("Debloat", "Weather", "GNOME Weather", "dnf", "gnome-weather"),
    ("Debloat", "Contacts", "GNOME Contacts", "dnf", "gnome-contacts"),
    ("Debloat", "Clocks", "World clocks, alarms and timers", "dnf", "gnome-clocks"),
    ("Debloat", "Characters", "Emoji and symbol picker", "dnf", "gnome-characters"),
    ("Debloat", "Connections", "Remote desktop client", "dnf", "gnome-connections"),
    ("Debloat", "Document Scanner", "Simple Scan", "dnf", "simple-scan"),
    ("Debloat", "Videos", "GNOME Videos (Totem)", "dnf", "totem"),
    ("Debloat", "Cheese", "Webcam app", "dnf", "cheese"),
    ("Debloat", "Boxes", "Virtual machines", "dnf", "gnome-boxes"),
    ("Debloat", "Rhythmbox", "Music player", "dnf", "rhythmbox"),
    ("Debloat", "Help", "Yelp help viewer", "dnf", "yelp"),
    ("Debloat", "Fedora Media Writer", "USB installer writer", "dnf", "mediawriter"),
    ("Debloat", "Problem Reporting", "ABRT crash reporter", "dnf", "gnome-abrt"),
]

# (title, subtitle, schema, key, value when ON, value when OFF)
GS_TWEAKS = [
    ("Dark mode", "Use the dark appearance everywhere", "org.gnome.desktop.interface", "color-scheme", "prefer-dark", "default"),
    ("macOS-style window buttons", "Close, minimize and maximize on the left", "org.gnome.desktop.wm.preferences", "button-layout", "close,minimize,maximize:", "appmenu:close"),
    ("Center new windows", "Open windows in the middle of the screen", "org.gnome.mutter", "center-new-windows", True, False),
    ("Show battery percentage", "In the top bar", "org.gnome.desktop.interface", "show-battery-percentage", True, False),
    ("Show seconds in the clock", "In the top bar", "org.gnome.desktop.interface", "clock-show-seconds", True, False),
    ("Show weekday in the clock", "In the top bar", "org.gnome.desktop.interface", "clock-show-weekday", True, False),
    ("Tap to click", "Touchpad", "org.gnome.desktop.peripherals.touchpad", "tap-to-click", True, False),
    ("Natural scrolling", "Touchpad scrolls like a phone", "org.gnome.desktop.peripherals.touchpad", "natural-scroll", True, False),
    ("Hot corner", "Open Activities when the pointer hits the top-left corner", "org.gnome.desktop.interface", "enable-hot-corners", True, False),
    ("Animations", "Window and shell animations", "org.gnome.desktop.interface", "enable-animations", True, False),
    ("Download updates in the background", "GNOME Software, turn off to save resources", "org.gnome.software", "download-updates", True, False),
]

SYSTEM_TWEAKS = [
    ("Faster DNF downloads", "Download 10 packages in parallel",
     "grep -q '^max_parallel_downloads' /etc/dnf/dnf.conf || echo 'max_parallel_downloads=10' >> /etc/dnf/dnf.conf\n"
     "echo 'DNF now downloads in parallel.'\n"),
    ("Faster boot", "Stop waiting for the network at startup",
     "systemctl disable NetworkManager-wait-online.service\n"),
    ("Weekly SSD TRIM", "Keeps SSDs fast",
     "systemctl enable --now fstrim.timer\n"),
    ("Trim system logs", "Keep the journal under 200 MB",
     "journalctl --vacuum-size=200M\n"),
]

SOURCES = {"flatpak": "Flatpak", "dnf": "DNF", "fusion": "DNF", "script": "Repo"}
GRUB_STYLES = ["menu", "countdown", "hidden"]
GRUB_DEFAULTS = ["saved", "0"]


# ---------------------------------------------------------------- helpers ---

def out(cmd, timeout=6):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "").strip()
    except Exception:
        return ""


def root(script):
    """Run a script as root through polkit (shows the normal GNOME password prompt)."""
    return "pkexec bash -c " + q("set -e\n" + script)


def build_install(entries):
    rootpart, flat, pkgs, fusion = "", [], [], False
    for a in entries:
        kind, target = a[3], a[4]
        if kind == "flatpak":
            flat.append(target)
        elif kind in ("dnf", "fusion"):
            pkgs.append(target)
            fusion = fusion or kind == "fusion"
        else:
            rootpart += SCRIPTS[target]
    if pkgs:
        rootpart = (RPMFUSION if fusion else "") + "dnf install -y " + " ".join(pkgs) + "\n" + rootpart
    script = ""
    if rootpart:
        script += root(rootpart) + "\n"
    if flat:
        script += FLATHUB + "flatpak install --user -y --noninteractive flathub " + " ".join(flat) + "\n"
    return script


def gpu_name(line):
    return re.sub(r"^\S+\s.*?\]:\s*", "", line)


def monitors():
    modes = {}
    for p in glob.glob("/sys/class/drm/card*-*"):
        try:
            with open(p + "/status") as f:
                if f.read().strip() != "connected":
                    continue
            with open(p + "/modes") as f:
                modes[os.path.basename(p).split("-", 1)[1]] = f.read().split()[0]
        except (OSError, IndexError):
            pass
    res = []
    disp = Gdk.Display.get_default()
    lst = disp.get_monitors() if disp else None
    for i in range(lst.get_n_items() if lst else 0):
        m = lst.get_item(i)
        g = m.get_geometry()
        conn = m.get_connector() or "Display %d" % (i + 1)
        name = " ".join(x for x in (m.get_manufacturer(), m.get_model()) if x) or conn
        res.append({"conn": conn, "name": name, "size": modes.get(conn) or "%dx%d" % (g.width, g.height)})
    return res


def find_grub_cfg():
    for p in ("/boot/grub2/grub.cfg", "/boot/grub/grub.cfg", "/boot/efi/EFI/fedora/grub.cfg"):
        if os.path.exists(p):
            return p
    return "/boot/grub2/grub.cfg"


def parse_grub(text):
    d = {}
    for m in re.finditer(r"^([A-Z_]+)=(.*)$", text, re.M):
        v = m.group(2).strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        d[m.group(1)] = v
    return d


def set_kv(text, key, value, quote=True):
    line = '%s="%s"' % (key, value) if quote else "%s=%s" % (key, value)
    pat = re.compile(r"^%s=.*$" % re.escape(key), re.M)
    if pat.search(text):
        return pat.sub(lambda m: line, text, count=1)
    return text.rstrip("\n") + "\n" + line + "\n"


def del_key(text, key):
    return re.sub(r"^%s=.*\n?" % re.escape(key), "", text, flags=re.M)


def ini_set(text, section, key, value):
    lines, sec, sec_idx, done = text.splitlines(), None, None, False
    for i, l in enumerate(lines):
        s = l.strip()
        if s.startswith("[") and s.endswith("]"):
            sec = s[1:-1]
            if sec == section:
                sec_idx = i
        elif sec == section and re.match(r"#?\s*%s\s*=" % re.escape(key), s):
            lines[i], done = "%s=%s" % (key, value), True
            break
    if not done:
        if sec_idx is None:
            lines += ["[%s]" % section, "%s=%s" % (key, value)]
        else:
            lines.insert(sec_idx + 1, "%s=%s" % (key, value))
    return "\n".join(lines) + "\n"


def to_int(v, default):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def index_of(lst, v, default=0):
    return lst.index(v) if v in lst else default


def find_theme_txt(path, depth=3):
    base = path.rstrip("/").count("/")
    for r, dirs, files in os.walk(path):
        if r.count("/") - base >= depth:
            dirs[:] = []
        if "theme.txt" in files:
            return r
    return None


def detect_theme(p):
    kinds = []
    if os.path.isdir(p + "/gtk-4.0") or os.path.isdir(p + "/gtk-3.0"):
        kinds.append("gtk")
    if os.path.isdir(p + "/gnome-shell"):
        kinds.append("shell")
    if os.path.isdir(p + "/cursors"):
        kinds.append("cursor")
    elif not kinds and os.path.isfile(p + "/index.theme"):
        try:
            with open(p + "/index.theme", errors="ignore") as f:
                if "Directories=" in f.read():
                    kinds.append("icons")
        except OSError:
            pass
    return kinds


def info_row(title, value):
    r = Adw.ActionRow(title=title, subtitle=esc(value or "-"))
    r.add_css_class("property")
    r.set_subtitle_selectable(True)
    return r


def action_row(title, subtitle, label, cb, suggested=False):
    r = Adw.ActionRow(title=title, subtitle=esc(subtitle))
    b = Gtk.Button(label=label, valign=Gtk.Align.CENTER)
    b.add_css_class("suggested-action" if suggested else "pill-btn")
    b.connect("clicked", lambda *_: cb())
    r.add_suffix(b)
    r.set_activatable_widget(b)
    return r


def confirm(parent, heading, body, ok_label, cb, destructive=False):
    d = Adw.AlertDialog(heading=heading, body=body)
    d.add_response("cancel", "Cancel")
    d.add_response("ok", ok_label)
    d.set_response_appearance("ok", Adw.ResponseAppearance.DESTRUCTIVE if destructive else Adw.ResponseAppearance.SUGGESTED)
    d.set_default_response("cancel")
    d.set_close_response("cancel")

    def done(dlg, res):
        if dlg.choose_finish(res) == "ok":
            cb()

    d.choose(parent, None, done)


def notice(parent, heading, body):
    d = Adw.AlertDialog(heading=heading, body=body)
    d.add_response("ok", "OK")
    d.present(parent)


# ------------------------------------------------------------ task window ---

class TaskWindow(Adw.Window):
    """Shows live output of a shell script."""

    def __init__(self, parent, title, script, on_close=None):
        super().__init__(transient_for=parent, modal=True, default_width=780, default_height=500, title=title)
        self.on_close = on_close
        self.wt = Adw.WindowTitle(title=title, subtitle="Running...")
        head = Adw.HeaderBar()
        head.set_title_widget(self.wt)
        head.set_decoration_layout("close:")
        self.spinner = Gtk.Spinner(spinning=True)
        head.pack_end(self.spinner)
        self.view = Gtk.TextView(editable=False, cursor_visible=False, monospace=True,
                                 wrap_mode=Gtk.WrapMode.WORD_CHAR, left_margin=16, right_margin=16,
                                 top_margin=12, bottom_margin=12)
        self.buf = self.view.get_buffer()
        self.mark = self.buf.create_mark("end", self.buf.get_end_iter(), False)
        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_child(self.view)
        self.close_btn = Gtk.Button(label="Done", halign=Gtk.Align.CENTER, visible=False,
                                    margin_top=10, margin_bottom=10)
        self.close_btn.add_css_class("suggested-action")
        self.close_btn.connect("clicked", lambda *_: self.close())
        tv = Adw.ToolbarView()
        tv.add_top_bar(head)
        tv.set_content(scroll)
        tv.add_bottom_bar(self.close_btn)
        self.set_content(tv)
        self.connect("close-request", self._closing)
        threading.Thread(target=self._run, args=(script,), daemon=True).start()

    def _run(self, script):
        env = dict(os.environ, TERM="dumb")
        rc = 1
        try:
            p = subprocess.Popen(["bash", "-c", "set -eo pipefail\n" + script], stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True,
                                 bufsize=1, env=env)
            for line in p.stdout:
                GLib.idle_add(self._add, line)
            rc = p.wait()
        except Exception as e:
            GLib.idle_add(self._add, "%s\n" % e)
        GLib.idle_add(self._done, rc)

    def _add(self, text):
        self.buf.insert(self.buf.get_end_iter(), ANSI.sub("", text).replace("\r", "\n"))
        self.view.scroll_to_mark(self.mark, 0.0, False, 0.0, 0.0)
        return False

    def _done(self, rc):
        self.spinner.stop()
        if rc == 0:
            msg, sub = "\nDone.\n", "Finished"
        elif rc in (126, 127):
            msg, sub = "\nPassword prompt was cancelled or refused.\n", "Cancelled"
        else:
            msg, sub = "\nSomething failed (exit code %d). Scroll up for details.\n" % rc, "Failed"
        self._add(msg)
        self.wt.set_subtitle(sub)
        self.close_btn.set_visible(True)
        return False

    def _closing(self, *_):
        cb, self.on_close = self.on_close, None
        if cb:
            cb()
        return False


# ------------------------------------------------------------ main window ---

class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Fedora Toolbox", default_width=1120, default_height=740)
        self.app_store, self.nv_store, self.bloat_store, self.app_groups = [], [], [], []
        self.rpms, self.flats = set(), set()
        self.load_state()
        self.mons = monitors()
        self.sb = out(["mokutil", "--sb-state"])

        self.toasts = Adw.ToastOverlay()
        self.set_content(self.toasts)
        self.split = Adw.NavigationSplitView()
        self.split.set_min_sidebar_width(230)
        self.split.set_max_sidebar_width(270)
        self.toasts.set_child(self.split)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        pages = [
            ("System", "computer-symbolic", self.page_system),
            ("NVIDIA", "video-display-symbolic", self.page_nvidia),
            ("Apps", "system-software-install-symbolic", self.page_apps),
            ("Boot and GRUB", "drive-harddisk-symbolic", self.page_boot),
            ("Login Screen", "system-users-symbolic", self.page_login),
            ("Themes", "preferences-desktop-appearance-symbolic", self.page_themes),
            ("Tweaks", "preferences-system-symbolic", self.page_tweaks),
        ]
        lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE, margin_start=6, margin_end=6)
        lb.add_css_class("navigation-sidebar")
        self.rows = {}
        for name, icon, build in pages:
            self.stack.add_named(build(), name)
            box = Gtk.Box(spacing=10, margin_top=5, margin_bottom=5, margin_start=6)
            box.append(Gtk.Image.new_from_icon_name(icon))
            box.append(Gtk.Label(label=name, xalign=0))
            row = Gtk.ListBoxRow(child=box)
            row.page_name = name
            lb.append(row)
            self.rows[name] = row

        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        side.append(Gtk.Label(label="Fedora Toolbox", xalign=0, margin_start=20, margin_top=8,
                              margin_bottom=10, css_classes=["title-3"]))
        side.append(lb)
        side_scroll = Gtk.ScrolledWindow(vexpand=True)
        side_scroll.set_child(side)
        side_head = Adw.HeaderBar()
        side_head.set_show_title(False)
        side_head.set_decoration_layout("close,minimize,maximize:")
        side_view = Adw.ToolbarView()
        side_view.add_top_bar(side_head)
        side_view.set_content(side_scroll)
        self.split.set_sidebar(Adw.NavigationPage.new(side_view, "Fedora Toolbox"))

        content_head = Adw.HeaderBar()
        content_head.set_decoration_layout(":")
        content_view = Adw.ToolbarView()
        content_view.add_top_bar(content_head)
        content_view.set_content(self.stack)
        self.content_page = Adw.NavigationPage.new(content_view, "System")
        self.split.set_content(self.content_page)

        self.refresh_rows()
        lb.connect("row-selected", self.on_nav)
        lb.select_row(self.rows["System"])

    # -- plumbing

    def on_nav(self, _lb, row):
        if row is not None:
            self.stack.set_visible_child_name(row.page_name)
            self.content_page.set_title(row.page_name)
            self.split.set_show_content(True)

    def goto(self, name):
        row = self.rows[name]
        row.get_parent().select_row(row)

    def toast(self, msg):
        self.toasts.add_toast(Adw.Toast.new(msg))

    def run(self, title, script):
        TaskWindow(self, title, script, self.after_task).present()

    def after_task(self):
        self.load_state()
        self.refresh_rows()

    def load_state(self):
        self.rpms = set(out(["rpm", "-qa", "--qf", "%{NAME}\\n%{NAME}.%{ARCH}\\n"], 40).split())
        self.flats = set(out(["flatpak", "list", "--app", "--columns=application"], 15).split())

    def is_installed(self, a):
        if a[3] == "flatpak":
            return a[4] in self.flats
        chk = a[5] if len(a) > 5 else (a[4].split()[0] if a[3] in ("dnf", "fusion") else "")
        return bool(chk) and chk in self.rpms

    def pick_row(self, e, store, changed):
        row = Adw.ActionRow(title=e[1], subtitle=esc(e[2]))
        chk = Gtk.CheckButton(valign=Gtk.Align.CENTER)
        tag = Gtk.Label(valign=Gtk.Align.CENTER)
        tag.add_css_class("dim-label")
        row.add_prefix(chk)
        row.add_suffix(tag)
        row.set_activatable_widget(chk)
        chk.connect("toggled", lambda *_: changed())
        store.append((e, row, chk, tag))
        return row

    def update_btn(self, store, btn, word):
        n = sum(1 for e, r, c, t in store if c.get_active() and c.get_sensitive())
        btn.set_sensitive(n > 0)
        btn.set_label("%s selected (%d)" % (word, n) if n else "%s selected" % word)

    def refresh_rows(self):
        for e, row, chk, tag in self.app_store + self.nv_store:
            inst = self.is_installed(e)
            chk.set_sensitive(not inst)
            if inst:
                chk.set_active(False)
            tag.set_label("Installed" if inst else SOURCES.get(e[3], ""))
        for e, row, chk, tag in self.bloat_store:
            inst = self.is_installed(e)
            row.set_visible(inst)
            if not inst:
                chk.set_active(False)
        self.update_btn(self.app_store, self.app_btn, "Install")
        self.update_btn(self.nv_store, self.nv_btn, "Install")
        self.update_btn(self.bloat_store, self.bloat_btn, "Remove")

    def selected(self, store):
        return [e for e, r, c, t in store if c.get_active() and c.get_sensitive()]

    def pick_folder(self, title, cb):
        dlg = Gtk.FileDialog(title=title)

        def done(d, res):
            try:
                f = d.select_folder_finish(res)
            except GLib.Error:
                return
            if f and f.get_path():
                cb(f.get_path())

        dlg.select_folder(self, None, done)

    # -- System

    def page_system(self):
        osr = {}
        try:
            with open("/etc/os-release") as f:
                for line in f:
                    if "=" in line:
                        k, v = line.strip().split("=", 1)
                        osr[k] = v.strip('"')
        except OSError:
            pass
        gpus = [gpu_name(l) for l in out(["lspci", "-nn"]).splitlines() if re.search(r"VGA|3D controller|Display", l)]
        about = Adw.PreferencesGroup(title="About this system")
        for k, v in (("Operating system", osr.get("PRETTY_NAME")), ("Kernel", platform.release()),
                     ("Desktop", out(["gnome-shell", "--version"])),
                     ("Session", (os.environ.get("XDG_SESSION_TYPE") or "").capitalize()),
                     ("Graphics", "\n".join(gpus)), ("Secure Boot", self.sb)):
            about.add(info_row(k, v))

        maint = Adw.PreferencesGroup(title="Maintenance")
        maint.add(action_row("Update system", "Runs dnf update -y (asks for your password)", "Update",
                             lambda: self.run("Update system", root("dnf update -y --refresh")), True))
        maint.add(action_row("Update Flatpak apps", "Updates everything installed from Flathub", "Update",
                             lambda: self.run("Update Flatpak apps", "flatpak update -y")))
        maint.add(action_row("Firmware updates", "BIOS, SSD and device firmware via fwupd", "Check",
                             lambda: self.run("Firmware updates", root(
                                 "fwupdmgr refresh --force || true\nfwupdmgr get-updates || true\n"
                                 "fwupdmgr update -y --no-reboot-check || true\n"))))
        maint.add(action_row("Clean up", "Remove unused dependencies and cached packages", "Clean",
                             lambda: self.run("Clean up", root("dnf autoremove -y\ndnf clean all\n"))))

        repos = Adw.PreferencesGroup(title="Repositories and codecs")
        repos.add(action_row("Enable RPM Fusion", "Free and nonfree repositories (needed for NVIDIA and Steam)", "Enable",
                             lambda: self.run("Enable RPM Fusion", root(RPMFUSION))))
        repos.add(action_row("Enable Flathub", "Adds the Flathub store for your user", "Enable",
                             lambda: self.run("Enable Flathub", FLATHUB + "echo 'Flathub is ready.'")))
        repos.add(action_row("Install multimedia codecs", "Full FFmpeg and GStreamer codecs from RPM Fusion", "Install",
                             lambda: self.run("Multimedia codecs", root(CODECS))))
        return self.make_page(about, maint, repos)

    @staticmethod
    def make_page(*groups):
        p = Adw.PreferencesPage()
        for g in groups:
            p.add(g)
        return p

    # -- NVIDIA

    def page_nvidia(self):
        gpu = [gpu_name(l) for l in out(["lspci", "-nn"]).splitlines() if "10de:" in l]
        smi = out(["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"])
        status = Adw.PreferencesGroup(title="Status")
        status.add(info_row("GPU", gpu[0] if gpu else "No NVIDIA GPU found"))
        status.add(info_row("Driver", smi.replace(", ", "   driver ") if smi
                            else "Not installed, or not loaded yet (reboot after installing)"))
        status.add(info_row("Secure Boot", self.sb))

        install_script = (
            RPMFUSION
            + "dnf install -y akmod-nvidia xorg-x11-drv-nvidia-cuda\n"
            + "echo\necho 'Building the kernel module. This can take a few minutes...'\n"
            + "akmods --force\ndracut --force\n"
            + "echo\nmodinfo -F version nvidia || echo 'Module not built yet - wait a few minutes before rebooting.'\n"
            + "echo 'Finished. Reboot to load the driver.'\n"
        )
        drv = Adw.PreferencesGroup(title="Driver", description="RTX 40-series cards use RPM Fusion's current driver branch.")
        drv.add(action_row(
            "Install NVIDIA driver", "akmod-nvidia and CUDA support from RPM Fusion", "Install",
            lambda: confirm(self, "Install the NVIDIA driver?",
                            "This enables RPM Fusion and installs the proprietary driver. "
                            "Wait for the module build to finish, then reboot.",
                            "Install", lambda: self.run("Install NVIDIA driver", root(install_script))), True))
        drv.add(action_row("Reboot", "Needed after installing or updating the driver", "Reboot",
                           lambda: confirm(self, "Reboot now?", "Save your work first.", "Reboot",
                                           lambda: subprocess.Popen(["systemctl", "reboot"]))))
        groups = [status, drv]

        if "enabled" in self.sb.lower():
            cmds = ("sudo kmodgenca -a\nsudo mokutil --import /etc/pki/akmods/certs/public_key.der\n"
                    "# Choose a one-time password, reboot, then pick 'Enroll MOK' on the blue screen.")
            sb = Adw.PreferencesGroup(title="Secure Boot is on",
                                      description="The driver module must be signed and its key enrolled, or it will not load.")
            sb.add(action_row("Copy key enrollment commands", "Paste them into a terminal (the password prompt needs one)",
                              "Copy", lambda: (self.get_clipboard().set_text(cmds), self.toast("Commands copied"))))
            groups.append(sb)

        extras = Adw.PreferencesGroup(title="Optional extras", description="Tick what you want, then install.")
        self.nv_btn = Gtk.Button(label="Install selected", sensitive=False)
        self.nv_btn.add_css_class("suggested-action")
        self.nv_btn.connect("clicked", lambda *_: self.run("Install NVIDIA extras", build_install(self.selected(self.nv_store))))
        extras.set_header_suffix(self.nv_btn)
        for e in NV_EXTRAS:
            extras.add(self.pick_row(e, self.nv_store, lambda: self.update_btn(self.nv_store, self.nv_btn, "Install")))
        groups.append(extras)
        return self.make_page(*groups)

    # -- Apps

    def page_apps(self):
        top = Adw.PreferencesGroup()
        box = Gtk.Box(spacing=10)
        self.search = Gtk.SearchEntry(hexpand=True, placeholder_text="Search apps")
        self.search.connect("search-changed", self.filter_apps)
        self.app_btn = Gtk.Button(label="Install selected", sensitive=False)
        self.app_btn.add_css_class("suggested-action")
        self.app_btn.connect("clicked", lambda *_: self.run("Installing apps", build_install(self.selected(self.app_store))))
        box.append(self.search)
        box.append(self.app_btn)
        top.add(box)
        groups, cats = [top], {}
        for a in APPS:
            cats.setdefault(a[0], []).append(a)
        for cat, items in cats.items():
            g = Adw.PreferencesGroup(title=cat)
            rows = []
            for a in items:
                row = self.pick_row(a, self.app_store, lambda: self.update_btn(self.app_store, self.app_btn, "Install"))
                g.add(row)
                rows.append((a, row))
            self.app_groups.append((g, rows))
            groups.append(g)
        return self.make_page(*groups)

    def filter_apps(self, entry):
        t = entry.get_text().lower().strip()
        for g, rows in self.app_groups:
            shown = 0
            for a, row in rows:
                show = t in (a[1] + " " + a[2]).lower()
                row.set_visible(show)
                shown += 1 if show else 0
            g.set_visible(shown > 0)

    # -- Boot and GRUB

    def page_boot(self):
        try:
            with open("/etc/default/grub") as f:
                self.grub_text = f.read()
        except OSError:
            self.grub_text = ""
        d = parse_grub(self.grub_text)
        self.grub_cfg = find_grub_cfg()
        self.themes_dir = os.path.join(os.path.dirname(self.grub_cfg), "themes")
        self.theme_src = None
        try:
            themes = sorted(os.listdir(self.themes_dir))
        except OSError:
            themes = []

        found = Adw.PreferencesGroup(title="Detected automatically")
        for k, v in (("Boot mode", "UEFI" if os.path.isdir("/sys/firmware/efi") else "Legacy BIOS"),
                     ("Settings file", "/etc/default/grub" + ("" if self.grub_text else "  (not found)")),
                     ("Generated menu", self.grub_cfg), ("Theme folder", self.themes_dir),
                     ("Installed themes", ", ".join(themes) or "None yet")):
            found.add(info_row(k, v))

        presets = Adw.PreferencesGroup(title="Quick presets", description="Fills in the settings below. Nothing is written until you press Apply.")
        presets.add(action_row("Fast boot", "Hide the menu, boot straight away", "Load", lambda: self.preset(0, "hidden", False)))
        presets.add(action_row("Show the menu", "Wait 5 seconds so you can pick", "Load", lambda: self.preset(5, "menu", None)))
        presets.add(action_row("Dual boot", "Find Windows and other systems, 8 second menu", "Load", lambda: self.preset(8, "menu", True)))

        s = Adw.PreferencesGroup(title="Settings")
        self.g_timeout = Adw.SpinRow.new_with_range(0, 60, 1)
        self.g_timeout.set_title("Menu timeout (seconds)")
        self.g_timeout.set_value(to_int(d.get("GRUB_TIMEOUT"), 5))
        self.g_style = Adw.ComboRow(title="Menu visibility")
        self.g_style.set_model(Gtk.StringList.new(["Show menu", "Countdown", "Hidden (hold Shift to open)"]))
        self.g_style.set_selected(index_of(GRUB_STYLES, d.get("GRUB_TIMEOUT_STYLE", "menu")))
        self.g_default = Adw.ComboRow(title="Default entry")
        self.g_default.set_model(Gtk.StringList.new(["Last booted entry", "Newest kernel"]))
        self.def_orig = d.get("GRUB_DEFAULT", "saved")
        self.g_default.set_selected(index_of(GRUB_DEFAULTS, self.def_orig))
        self.g_gfx = Adw.EntryRow(title="Menu resolution (auto, or e.g. 2560x1440)")
        self.g_gfx.set_text(d.get("GRUB_GFXMODE", "auto"))
        self.g_cmd = Adw.EntryRow(title="Kernel parameters")
        self.g_cmd.set_text(d.get("GRUB_CMDLINE_LINUX", ""))
        self.g_os = Adw.SwitchRow(title="Detect other operating systems", subtitle="Adds Windows and other systems to the menu (installs os-prober)")
        self.g_os.set_active(d.get("GRUB_DISABLE_OS_PROBER", "true") == "false")
        self.g_theme = Adw.EntryRow(title="Theme (path to theme.txt)")
        self.g_theme.set_text(d.get("GRUB_THEME", ""))
        pick = Gtk.Button(label="Choose folder...", valign=Gtk.Align.CENTER)
        pick.add_css_class("pill-btn")
        pick.connect("clicked", lambda *_: self.pick_folder("Choose a GRUB theme folder", self.use_grub_theme))
        self.g_theme.add_suffix(pick)
        for w in (self.g_timeout, self.g_style, self.g_default, self.g_gfx, self.g_cmd, self.g_os, self.g_theme):
            s.add(w)

        mons = Adw.PreferencesGroup(title="Your monitors", description="Match the GRUB menu to a screen's native resolution.")
        for m in self.mons:
            mons.add(action_row(m["name"], "%s  -  %s" % (m["conn"], m["size"]), "Use for GRUB",
                                lambda size=m["size"]: (self.g_gfx.set_text(size + ",auto"), self.toast("Resolution set, press Apply"))))
        if not self.mons:
            mons.add(info_row("No monitors detected", ""))

        apply = Adw.PreferencesGroup()
        apply.add(action_row("Apply and rebuild GRUB", "Backs up /etc/default/grub, saves your settings, regenerates the menu",
                             "Apply", self.apply_grub, True))
        apply.add(action_row("Rebuild only", "Regenerate grub.cfg without changing settings", "Rebuild",
                             lambda: self.run("Rebuild GRUB", root("grub2-mkconfig -o %s\n" % q(self.grub_cfg)))))
        return self.make_page(found, presets, s, mons, apply)

    def preset(self, timeout, style, osprobe):
        self.g_timeout.set_value(timeout)
        self.g_style.set_selected(GRUB_STYLES.index(style))
        if osprobe is not None:
            self.g_os.set_active(osprobe)
        self.toast("Preset loaded, press Apply to write it")

    def use_grub_theme(self, path):
        src = find_theme_txt(path)
        if not src:
            self.toast("No theme.txt found in that folder")
            return
        self.theme_src = src
        self.g_theme.set_text("%s/%s/theme.txt" % (self.themes_dir, os.path.basename(src.rstrip("/"))))
        self.goto("Boot and GRUB")
        self.toast("GRUB theme found, press Apply to install it")

    def apply_grub(self):
        old = parse_grub(self.grub_text)
        t, pre = self.grub_text, ""
        t = set_kv(t, "GRUB_TIMEOUT", int(self.g_timeout.get_value()), False)
        t = set_kv(t, "GRUB_TIMEOUT_STYLE", GRUB_STYLES[self.g_style.get_selected()])
        sel = self.g_default.get_selected()
        if self.def_orig in GRUB_DEFAULTS or sel != 0:
            t = set_kv(t, "GRUB_DEFAULT", GRUB_DEFAULTS[sel])
        gfx = self.g_gfx.get_text().strip().replace('"', "")
        if gfx:
            t = set_kv(t, "GRUB_GFXMODE", gfx)
            if gfx != "auto":
                t = set_kv(t, "GRUB_GFXPAYLOAD_LINUX", "keep")
        cmd = self.g_cmd.get_text().strip().replace('"', "")
        t = set_kv(t, "GRUB_CMDLINE_LINUX", cmd)
        if self.g_os.get_active():
            t = set_kv(t, "GRUB_DISABLE_OS_PROBER", "false")
            pre += "rpm -q os-prober >/dev/null 2>&1 || dnf install -y os-prober\n"
        elif "GRUB_DISABLE_OS_PROBER" in old:
            t = set_kv(t, "GRUB_DISABLE_OS_PROBER", "true")
        theme = self.g_theme.get_text().strip()
        if self.theme_src:
            name = os.path.basename(self.theme_src.rstrip("/"))
            dest = "%s/%s" % (self.themes_dir, name)
            if theme == dest + "/theme.txt":
                pre += "mkdir -p %s\nrm -rf %s\ncp -r %s %s\n" % (q(self.themes_dir), q(dest), q(self.theme_src), q(dest))
        if theme:
            t = set_kv(t, "GRUB_THEME", theme)
            t = set_kv(t, "GRUB_TERMINAL_OUTPUT", "gfxterm")
        else:
            t = del_key(t, "GRUB_THEME")
        try:
            before, after = shlex.split(old.get("GRUB_CMDLINE_LINUX", "")), shlex.split(cmd)
        except ValueError:
            before, after = old.get("GRUB_CMDLINE_LINUX", "").split(), cmd.split()
        add, rem = [x for x in after if x not in before], [x for x in before if x not in after]
        if add or rem:
            pre += "grubby --update-kernel=ALL"
            pre += " --args=%s" % q(" ".join(add)) if add else ""
            pre += " --remove-args=%s" % q(" ".join(rem)) if rem else ""
            pre += "\n"
        fd, tmp = tempfile.mkstemp(prefix="toolbox-grub-")
        os.write(fd, t.encode())
        os.close(fd)
        os.chmod(tmp, 0o644)
        script = ("cp -a /etc/default/grub /etc/default/grub.toolbox-$(date +%Y%m%d-%H%M%S).bak\n"
                  "install -m 644 %s /etc/default/grub\nrm -f %s\n" % (q(tmp), q(tmp))
                  + pre + "grub2-mkconfig -o %s\n" % q(self.grub_cfg)
                  + "echo\necho 'GRUB updated. Changes show up on the next boot.'\n")
        self.grub_text = t
        self.run("Apply GRUB settings", root(script))

    # -- Login screen

    def page_login(self):
        dm = os.path.basename(os.path.realpath("/etc/systemd/system/display-manager.service")).replace(".service", "")
        if dm == "display-manager":
            dm = "unknown"
        info = Adw.PreferencesGroup(title="Detected automatically")
        info.add(info_row("Login manager", dm.upper() if dm == "gdm" else dm))
        info.add(info_row("Your saved display layout", "Found" if os.path.exists(HOME + "/.config/monitors.xml")
                          else "Not saved yet. Open Settings > Displays and press Apply once."))
        info.add(info_row("Login screen layout", "Custom" if os.path.exists("/var/lib/gdm/.config/monitors.xml") else "Default"))

        mons = Adw.PreferencesGroup(title="Show the login screen on", description="GNOME draws the login screen on the primary monitor. Pick the one you want.")
        for m in self.mons:
            mons.add(action_row(m["name"], "%s  -  %s" % (m["conn"], m["size"]), "Use this one",
                                lambda c=m["conn"]: self.login_layout(c), True))
        mons.add(action_row("Copy my current layout", "Use your display layout exactly as it is now", "Copy", lambda: self.login_layout(None)))
        mons.add(action_row("Reset to default", "Remove the custom login screen layout", "Reset",
                            lambda: self.run("Reset login layout", root("rm -f /var/lib/gdm/.config/monitors.xml\necho 'Login layout reset.'\n"))))
        mons.add(action_row("Open Displays settings", "Rearrange or set your primary monitor first", "Open",
                            lambda: subprocess.Popen(["gnome-control-center", "display"])))

        user = GLib.get_user_name()
        self.conf = "/etc/gdm/custom.conf"
        try:
            with open(self.conf) as f:
                self.conf_text = f.read()
        except OSError:
            self.conf_text = "[daemon]\n"
        auto = Adw.PreferencesGroup(title="Automatic login")
        self.auto = Adw.SwitchRow(title="Log in automatically as %s" % user, subtitle="Skips the password at startup. Your keyring will not unlock itself.")
        self.auto.set_active(re.search(r"^AutomaticLoginEnable\s*=\s*(true|1)", self.conf_text, re.I | re.M) is not None)
        auto.add(self.auto)
        auto.add(action_row("Apply automatic login", "Writes /etc/gdm/custom.conf (backup included)", "Apply",
                            lambda: self.apply_autologin(user), True))

        look = Adw.PreferencesGroup(title="Login screen look", description="GDM's background and theme live inside the shell, which needs a dedicated tool.")
        look.add(action_row("Install GDM Settings", "A small app for the login screen background and theme", "Install",
                            lambda: self.run("Install GDM Settings", FLATHUB + "flatpak install --user -y --noninteractive flathub io.github.realmazharhussain.GdmSettings")))
        return self.make_page(info, mons, auto, look)

    def login_layout(self, conn):
        src = HOME + "/.config/monitors.xml"
        if not os.path.exists(src):
            notice(self, "Save your display layout first", "Open Settings > Displays, press Apply once so GNOME saves your layout, then try again.")
            return
        fd, tmp = tempfile.mkstemp(prefix="toolbox-monitors-")
        os.close(fd)
        try:
            tree = ET.parse(src)
            if conn:
                for cfg in tree.getroot().iter("configuration"):
                    for lm in cfg.findall("logicalmonitor"):
                        for p in lm.findall("primary"):
                            lm.remove(p)
                        if conn in [c.text for c in lm.iter("connector")]:
                            p = ET.Element("primary")
                            p.text = "yes"
                            idx = 0
                            for i, ch in enumerate(list(lm)):
                                if ch.tag in ("x", "y", "scale"):
                                    idx = i + 1
                            lm.insert(idx, p)
            tree.write(tmp, encoding="utf-8")
        except (ET.ParseError, OSError):
            self.toast("Could not read your monitors.xml")
            return
        os.chmod(tmp, 0o644)
        script = ("mkdir -p /var/lib/gdm/.config\n"
                  "install -o gdm -g gdm -m 644 %s /var/lib/gdm/.config/monitors.xml\n"
                  "restorecon -R /var/lib/gdm/.config || true\nrm -f %s\n"
                  "echo 'Done. The login screen uses this layout after you log out or reboot.'\n" % (q(tmp), q(tmp)))
        self.run("Set login screen monitor", root(script))

    def apply_autologin(self, user):
        on = self.auto.get_active()
        t = ini_set(self.conf_text, "daemon", "AutomaticLoginEnable", "True" if on else "False")
        if on:
            t = ini_set(t, "daemon", "AutomaticLogin", user)
        fd, tmp = tempfile.mkstemp(prefix="toolbox-gdm-")
        os.write(fd, t.encode())
        os.close(fd)
        os.chmod(tmp, 0o644)
        self.conf_text = t
        script = ("[ -f %s ] && cp -a %s %s.toolbox.bak || true\nmkdir -p /etc/gdm\n"
                  "install -m 644 -o root -g root %s %s\nrm -f %s\necho 'Saved.'\n"
                  % (q(self.conf), q(self.conf), q(self.conf), q(tmp), q(self.conf), q(tmp)))
        self.run("Automatic login", root(script))

    # -- Themes

    def page_themes(self):
        g = Adw.PreferencesGroup(title="Install a theme", description="Pick a folder. GTK, icon, cursor, shell and GRUB themes are detected automatically.")
        g.add(action_row("Choose theme folder...", "A single theme, or a folder holding several", "Choose",
                         lambda: self.pick_folder("Choose a theme folder", self.install_theme_folder), True))
        self.theme_group = Adw.PreferencesGroup(title="Ready to apply", description="Themes you add show up here.")
        self.theme_group.set_visible(False)
        return self.make_page(g, self.theme_group)

    def install_theme_folder(self, path):
        if find_theme_txt(path):
            self.use_grub_theme(path)
            return
        cands = [path] + [os.path.join(path, n) for n in sorted(os.listdir(path)) if os.path.isdir(os.path.join(path, n))]
        script, added = "", []
        for c in cands:
            name = os.path.basename(c.rstrip("/"))
            for kind in detect_theme(c):
                base = HOME + ("/.local/share/themes" if kind in ("gtk", "shell") else "/.local/share/icons")
                dest = "%s/%s" % (base, name)
                if (c, dest) not in [(x, y) for x, y, _ in added]:
                    script += "mkdir -p %s\nrm -rf %s\ncp -r %s %s\n" % (q(base), q(dest), q(c), q(dest))
                added.append((c, dest, (kind, name)))
        if not added:
            self.toast("No GTK, icon, cursor or shell theme found in that folder")
            return
        for _c, _d, (kind, name) in added:
            label = {"gtk": "GTK theme", "icons": "Icon theme", "cursor": "Cursor theme", "shell": "Shell theme"}[kind]
            self.theme_group.add(action_row(name, label, "Apply", lambda n=name, k=kind: self.apply_theme(n, k)))
        self.theme_group.set_visible(True)
        self.run("Installing themes", script + "echo 'Installed. Press Apply next to the theme to use it.'\n")

    def apply_theme(self, name, kind):
        schema, key = {"gtk": ("org.gnome.desktop.interface", "gtk-theme"),
                       "icons": ("org.gnome.desktop.interface", "icon-theme"),
                       "cursor": ("org.gnome.desktop.interface", "cursor-theme"),
                       "shell": ("org.gnome.shell.extensions.user-theme", "name")}[kind]
        r = subprocess.run(["gsettings", "set", schema, key, name], capture_output=True, text=True)
        if r.returncode == 0:
            self.toast("Applied %s" % name)
        elif kind == "shell":
            self.toast("Install and enable the User Themes extension first (Apps > GNOME)")
        else:
            self.toast("Could not apply %s" % name)

    # -- Tweaks

    def page_tweaks(self):
        look = Adw.PreferencesGroup(title="Look and behavior", description="Applied instantly, only for your user.")
        src = Gio.SettingsSchemaSource.get_default()
        for title, sub, schema, key, on, off in GS_TWEAKS:
            try:
                if not src.lookup(schema, True):
                    continue
                gs = Gio.Settings.new(schema)
                cur = gs.get_value(key).unpack()
            except Exception:
                continue
            row = Adw.SwitchRow(title=title, subtitle=esc(sub))
            row.set_active(cur == on)
            fmt = "b" if isinstance(on, bool) else "s"
            row.connect("notify::active", lambda r, _p, gs=gs, key=key, on=on, off=off, fmt=fmt:
                        gs.set_value(key, GLib.Variant(fmt, on if r.get_active() else off)))
            look.add(row)

        sysg = Adw.PreferencesGroup(title="System tweaks")
        for title, sub, script in SYSTEM_TWEAKS:
            sysg.add(action_row(title, sub, "Apply", lambda t=title, s=script: self.run(t, root(s))))

        deb = Adw.PreferencesGroup(title="GNOME debloat", description="Only apps that are installed are listed.")
        self.bloat_btn = Gtk.Button(label="Remove selected", sensitive=False)
        self.bloat_btn.add_css_class("destructive-action")
        self.bloat_btn.connect("clicked", lambda *_: self.remove_bloat())
        deb.set_header_suffix(self.bloat_btn)
        for e in BLOAT:
            deb.add(self.pick_row(e, self.bloat_store, lambda: self.update_btn(self.bloat_store, self.bloat_btn, "Remove")))
        return self.make_page(look, sysg, deb)

    def remove_bloat(self):
        sel = self.selected(self.bloat_store)
        if not sel:
            return
        names = ", ".join(e[1] for e in sel)
        confirm(self, "Remove %d app(s)?" % len(sel), "%s\n\nDNF may also remove packages that depend on them." % names, "Remove",
                lambda: self.run("Removing apps", root("dnf remove -y " + " ".join(e[4] for e in sel) + "\n")), True)


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="dev.fedoratoolbox.App")

    def do_activate(self):
        css = Gtk.CssProvider()
        try:
            css.load_from_string(CSS)
        except AttributeError:
            css.load_from_data(CSS.encode())
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        win = self.props.active_window or Window(self)
        win.present()


if __name__ == "__main__":
    if os.geteuid() == 0:
        raise SystemExit("Run Fedora Toolbox as your normal user. It asks for your password only when needed.")
    raise SystemExit(App().run(sys.argv))
